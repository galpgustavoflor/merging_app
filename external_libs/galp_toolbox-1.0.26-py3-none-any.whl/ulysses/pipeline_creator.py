import requests
import json
import xml.etree.ElementTree as ET

import gitlab
import git


class PipelineManager:
    """
    The PipelineManager class manage Jenkins pipelines and Gitlab

    Attributes:
        jenkins_url (str): Jenkins URL for pipelines to be created
        jenkins_user (str): Programatic user to access Jenkins from code
        jenkins_token (str): Token defined for authentication
        project (str): Project ID at Galp -> PXXXXX
        github_repo (str): Repository name at Github
        template_job_name (str): Jenkins job used as template
    """

    def __init__(self, project, github_repo):
        """
        The constructor for Client class.

        Parameters:
            jenkins_url (str): Jenkins URL for pipelines to be created
            jenkins_user (str): Programatic user to access Jenkins from code
            jenkins_token (str): Token defined for authentication
            project (str): Project ID at Galp -> PXXXXX
            github_repo (str): Repository name at Github
            template_job_name (str): Jenkins job used as template
        """
        self.jenkins_url = 'http://prd-aws-ddp-jenkins-master.ulysses.galpenergia.corp/'
        self.jenkins_user = sagithub
        self.jenkins_token = '1186fdaf13c7dd8822bf126836624caa53'
        self.gitlab_url = 'http://gitlab.ulysses.galpenergia.corp'
        self.gitlab_token = 'hxkvVM9oP6ybP4TCbJwa'
        self.project = project
        self.github_repo = github_repo
        self.template_job_name = 'galp-coedaai-cortex-template-model'
        self.template_repo_name = 'galp-coedaai-mlops-template-project'
        self.model_name = self.github_repo.replace("data_science-", "").replace("_model", "").replace("-", " ").title()
        # ca_cert_path = '/home/jovyan/tests/certs/ulysses_ca_certs.crt'
        self.ca_cert_path = 'hub/docker/certificates/ca_bundle_ulysses.crt'

    @staticmethod
    def set_parent(element, parent=None):
        """
        Helper function to recursively set parent for each element
        """
        element.set('parent', parent)
        for child in element:
            set_parent(child, element)

    @staticmethod
    def remove_parent_attributes(element):
        """
        Remove parent attributes before converting back to string
        """
        element.attrib.pop('parent', None)
        for child in element:
            remove_parent_attributes(child)

    def create_automation_pipeline(self):

        model_name = self.github_repo.replace("data_science-", "").replace("_model", "").replace("-", " ").title()
        print(model_name)

        # Template job and new job names
        new_job_name = f'galp-coedaai-{self.project.lower()}-{model_name.replace(" ", "-").lower()}-model'
        print(f'Pipeline name is {new_job_name}.\n'
              f'This name must be configured in Github as repository variable with '
              f'name ULYSSES_PIPELINE_REPOSITORY_NAME and value {new_job_name}')

        pipeline_display_name = f'Galp CoE DAAI {model_name}'
        pipeline_description = f'Get files from a Github repository and build a docker image. ' \
                               f'This pipeline is for {model_name}.'

        print(pipeline_display_name)
        print(pipeline_description)

        # API URLs
        create_job_url = f'{self.jenkins_url}/createItem?name={new_job_name}'
        config_xml_url = f'{self.jenkins_url}/job/{self.template_job_name}/config.xml'

        response = requests.get(config_xml_url, auth=(self.jenkins_user, self.jenkins_token))
        if response.status_code != 200:
            print(f'Failed to get config.xml from template job: {response.status_code}')
            exit(1)

        config_xml = response.text

        new_values = {
            'displayName': pipeline_display_name,
            'pipeline_description': pipeline_description,
            'repository': self.github_repo,
            'repositoryUrl': 'https://github.com/galpenergia/' + self.github_repo,
            'includes': 'deployment_staging*'
        }

        # Load and parse XML template
        root = ET.fromstring(config_xml)

        # Set parent attributes
        set_parent(root)

        # Find and replace specific elements
        for elem in root.iter():
            if elem.tag == 'description':
                parent_tag = elem.get('parent').tag if elem.get('parent') is not None else None
                if 'WorkflowMultiBranchProject' in parent_tag:
                    elem.text = new_values['pipeline_description']
            elif elem.tag in new_values:
                elem.text = new_values[elem.tag]

        remove_parent_attributes(root)

        # Save the modified XML to a string
        modified_xml = ET.tostring(root, encoding='unicode')

        # Create the new job with the modified config.xml
        headers = {'Content-Type': 'application/xml'}
        response = requests.post(create_job_url, data=modified_xml, headers=headers,
                                 auth=(self.jenkins_user, self.jenkins_token))
        if response.status_code == 200:
            print(f'Successfully created job {new_job_name} from template {self.template_job_name}')
        else:
            print(f'Failed to create job: {response.status_code}')
            print(response.text)

    def create_ulysses_repository(self):

        # Names of the template repository and new repository
        template_repo_url = self.gitlab_url + "/cortex/" + self.template_repo_name + '.git'
        new_repo_name = f'galp-coedaai-{self.project.lower()}-{self.model_name.lower().replace(" ", "-")}-model'
        print(f'DEBUG: New repository {new_repo_name} will be created from template {template_repo_url}')

        gl = gitlab.Gitlab(self.gitlab_url, private_token=self.gitlab_token,
                           api_version=4, ssl_verify=self.ca_cert_path)
        gl.auth()

        # project_id for mlops models template.
        # project_id_template = 581
        # template_repo = gl.projects.get(project_id_template)

        group_id = gl.groups.list(search='cortex')[0].id  # Identify Cortex repository group

        # Clone the template repository locally
        clone_url = template_repo_url.replace('http://', f'https://oauth2:{self.gitlab_token}@')
        print(clone_url)

        local_path = '/tmp/template_repo'
        repo = git.Repo.clone_from(clone_url, local_path, config='http.sslVerify=false')
        print(f'New repository "{new_repo_name}" created from template repository "{self.template_repo_name}"')

        # Create a new repository on GitLab
        new_project = gl.projects.create({'name': new_repo_name, 'namespace_id': group_id})

        # Add the new repository as a remote and push the contents
        new_repo_url = new_project.http_url_to_repo.replace('http://', f'https://oauth2:{self.gitlab_token}@')
        origin = repo.create_remote('new_origin', new_repo_url)
        origin.push()

        # Create the master branch and push it to the new repository
        repo.git.checkout('-b', 'master')
        repo.git.push('new_origin', 'master')

        print(f'New repository created: {new_project.web_url}')
        print(f'Dev branch created and pushed to {new_project.web_url}')

        # Define variables for Gitlab CI/CD
        # TODO: set variables as environmental variables and secrets.
        # SBX variables may be different depending on the environment created.
        variables = [
            {'key': 'DB_NAME', 'value': 'dpm', 'protected': False, 'masked': False},
            {'key': 'DB_PASSWORD_PRD', 'value': 'OP0hC1Zk3NLylCS5tU8b', 'protected': False, 'masked': True},
            {'key': 'DB_PASSWORD_PRE', 'value': 'uIEuPpd6rsK4NTl0OVbU', 'protected': False, 'masked': True},
            {'key': 'DB_PASSWORD_QUA', 'value': 'TBLnLloMcuH4YU8ySBjX', 'protected': False, 'masked': True},
            {'key': 'DB_PASSWORD_SBX', 'value': 'cl4pGl0IzBuFhKeS9Zgm', 'protected': False, 'masked': True},
            {'key': 'DB_USERNAME_PRD', 'value': 'samlops', 'protected': False, 'masked': False},
            {'key': 'DPM_HOST_PRD', 'value': 'rds-dpm-postgresql-prd.c3htodb57kr6.eu-west-1.rds.amazonaws.com',
             'protected': False, 'masked': False},
            {'key': 'DPM_HOST_PRE', 'value': 'rds-dpm-postgresql-pre.ccoc4orb3auh.eu-west-1.rds.amazonaws.com',
             'protected': False, 'masked': False},
            {'key': 'DPM_HOST_QUA', 'value': 'rds-dpm-postgresql-qua.cdsa2uog6nxz.eu-west-1.rds.amazonaws.com',
             'protected': False, 'masked': False},
            {'key': 'DPM_HOST_SBX', 'value': 'rds-dpm-postgresql-sbx.capy0jxy5atc.eu-west-1.rds.amazonaws.com',
             'protected': False, 'masked': False},
            {'key': 'DPM_PORT', 'value': '5432', 'protected': False, 'masked': False},
            {'key': 'GITLAB_TOKEN', 'value': 'zZy-UkWz9f8Vk_enGnN8', 'protected': False, 'masked': True},
            {'key': 'GITLAB_USER', 'value': 'ulysses-gitlab-deploy', 'protected': False, 'masked': True}
        ]

        # Add each variable to the project
        for var in variables:
            try:
                new_project.variables.create(var)
                print(f"Variable {var['key']} added successfully.")
            except gitlab.exceptions.GitlabCreateError as e:
                print(f"Failed to add variable {var['key']}: {e}")
