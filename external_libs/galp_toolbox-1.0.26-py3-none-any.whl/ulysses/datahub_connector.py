from .pyarrow_client import connect_to_dremio_flight_server_endpoint

class Client:
    """
    The Client class represents a client for the Dremio server.
    
    Attributes:
    username (str): The username for authentication.
    password (str): The password for authentication.
    host (str): The hostname of the Dremio server.
    port (int): The port number of the Dremio server.
    """
    
    def __init__(self, username, password):
        """
        The constructor for Client class.
        
        Parameters:
        username (str): The username for authentication.
        password (str): The password for authentication.
        """
        self.username = username
        self.password = password
        self.host = "datahub.ulysses.galpenergia.corp"
        self.port = 32010

    def set_host(self, host=None, port=None):
        """
        The function to set a new host and port for the Dremio server.
        
        Parameters:
        host (str): The new hostname of the Dremio server. Defaults to None.
        port (int): The new port number of the Dremio server. Defaults to None.
        """
        if host is not None:
            self.host = host
        if port is not None:
            self.port = port
            
        print(f'[info] switched to {self.host} on port {self.port}')

    def query(self, query):
        """
        The function to execute a query on the Dremio server.
        
        Parameters:
        query (str): The query to be executed.
        
        Returns:
        pandas.DataFrame: The result of the query.
        """
        return connect_to_dremio_flight_server_endpoint(self.host, self.port, self.username, self.password, query, True, False, True, False, False, False)

    def list_tables(self):
        """
        The function to list all tables in the Dremio server.
        
        Returns:
        pandas.DataFrame: The list of tables.
        """
        query = 'SELECT * FROM INFORMATION_SCHEMA."TABLES"'
        return self.query(query)

    def list_columns(self, table):
        """
        The function to list all columns in a table.
        
        Parameters:
        table (str): The name of the table.
        
        Returns:
        pandas.DataFrame: The list of columns in the table.
        """
        query = f"SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='{table}'"
        return self.query(query)
