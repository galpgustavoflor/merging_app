import os
import sys
import subprocess
import boto3
import botocore
import pandas as pd

class EpacClusterManager:

    def __init__(self, PROJECT_NAME, OWNER_NAME, OWNER_EMAIL, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, ENVIRONMENT):
        PREFIX = 'DDP'
        SUFFIX = 'DSWKS'
        self.PROJECT_NAME = PROJECT_NAME #'sbx-mlops'#os.environ['PROJECT_NAME']
        self.OWNER_NAME = OWNER_NAME
        self.OWNER_EMAIL = OWNER_EMAIL #os.environ['OWNER_EMAIL']
        self.AWS_ACCESS_KEY_ID = AWS_ACCESS_KEY_ID # #os.environ['AWS_ACCESS_KEY_ID']
        self.AWS_SECRET_ACCESS_KEY = AWS_SECRET_ACCESS_KEY #os.environ['AWS_SECRET_ACCESS_KEY']
        self.ENVIRONMENT = ENVIRONMENT
        self.AWS_REGION = 'eu-west-1'
        self.EMR_LOGIN = 'hadoop'
        self.EMR = boto3.client(
            'emr',
            region_name=self.AWS_REGION,
            aws_access_key_id=self.AWS_ACCESS_KEY_ID,
            aws_secret_access_key=self.AWS_SECRET_ACCESS_KEY,
        )

        self.CLUSTER_NAME = self.ENVIRONMENT.upper()+'-'+PREFIX+'-'+self.PROJECT_NAME.upper()+'-'+self.OWNER_NAME.upper()+'-'+SUFFIX

    def create_cluster(self):
        """
        This function creates a specific AWS EMR Cluster and returns its ID.

        @param: cluster_name: Cluster name (default is "Airflow-Ingest-")
        @param: release_label: EMR release label (default is "emr-5.29.0")
        @param: owner: str: The DAG owner (default is 'dsi')
        @param: project: str: The DAG project (default is 'ulysses')
        @param: instance_type: Instance type index from table (default is 10: c5n.xlarge,4vpcu,10.5ram)
        @param: number_core_instances: Number of worker core instances (default is 3)
        @param: ebs_disk: Additional EBS disk space to be added to cluster (default is 500GB)
        @param: applications: EMR application list to be included in cluster
        """

        # Detailed information:
        #
        # Instance types table
        # N       name        vcpu    ram
        # 0       m1.medium     1       3.75    (minmal cluster boot,setup testing purposes only)
        # 1       c5.xlarge	    4	    8       (default, lowest compatible EMR instance type)
        # 2       c5.2xlarge	8	    16
        # 3       c5.4xlarge	16	    32
        # 4       c5.9xlarge	36	    72
        # 5       c5.12xlarge	48	    96
        # 6       c5.18xlarge	72	    144
        # 7       c5.24xlarge	96	    192
        # 10      c5n.xlarge	4	    10,5    Optmized for throughput and NVMe <4750 Mbps
        # 11      c5n.2xlarge	8	    21      <4750 Mbps
        # 12      c5n.4xlarge	16	    42      <4750 Mbps
        # 13      c5n.9xlarge	36	    96      <9500 Mbps
        # 20      d2.xlarge	    4	    30,5    3 x 2000 HDD    Optimized for high volume data size
        # 21      d2.2xlarge	8	    61  	6 x 2000 HDD    Optimized for high volume data size
        # 22      r5dn.2xlarge   8       64       

        cluster_name=self.CLUSTER_NAME
        release_label='emr-6.9.0'
        owner=self.OWNER_NAME
        project=self.PROJECT_NAME
        instance_type=22
        number_core_instances=3
        ebs_disk=500
        applications=['Hadoop', 'Spark', 'Hive']

        # Initialize instance type dictionary
        instance_types = {
            0: {"name": "m1.medium", "virtual_cores_per_instance": 1, "ram_per_instance": 3.75},

            1: {"name": "c5.xlarge", "virtual_cores_per_instance": 4, "ram_per_instance": 8},
            2: {"name": "c5.2xlarge", "virtual_cores_per_instance": 8, "ram_per_instance": 16},
            3: {"name": "c5.4xlarge", "virtual_cores_per_instance": 16, "ram_per_instance": 32},
            4: {"name": "c5.9xlarge", "virtual_cores_per_instance": 36, "ram_per_instance": 72},
            5: {"name": "c5.12xlarge", "virtual_cores_per_instance": 48, "ram_per_instance": 96},
            6: {"name": "c5.18xlarge", "virtual_cores_per_instance": 72, "ram_per_instance": 144},
            7: {"name": "c5.24xlarge", "virtual_cores_per_instance": 96, "ram_per_instance": 192},

            10: {"name": "c5n.xlarge", "virtual_cores_per_instance": 4, "ram_per_instance": 10.5},
            11: {"name": "c5n.2xlarge", "virtual_cores_per_instance": 8, "ram_per_instance": 21},
            12: {"name": "c5n.4xlarge", "virtual_cores_per_instance": 16, "ram_per_instance": 42},
            13: {"name": "c5n.9xlarge", "virtual_cores_per_instance": 36, "ram_per_instance": 96},

            20: {"name": "d2.xlarge", "virtual_cores_per_instance": 4, "ram_per_instance": 30.5},
            21: {"name": "d2.2xlarge", "virtual_cores_per_instance": 8, "ram_per_instance": 61},

            22: {"name": "r5dn.2xlarge", "virtual_cores_per_instance": 8, "ram_per_instance": 64}
        }

        # Gets selected instance type characteristics: type, vcpus, ram
        if instance_type in instance_types:

            instance_type_name = instance_types[instance_type]["name"]
            virtual_cores_per_instance = instance_types[instance_type]["virtual_cores_per_instance"]
            ram_per_instance = instance_types[instance_type]["ram_per_instance"]

            print(f"Starting EMR cluster with {number_core_instances} cores of {instance_type_name} "
                f"({virtual_cores_per_instance} vpcus and {ram_per_instance} ram per instance)")
        else:
            raise Exception(f'ERROR: invalid instance_type value:{instance_type}')

        # Setups EBS additional disk configuration
        if ebs_disk > 0:
            ebs_configuration = {
                'EbsBlockDeviceConfigs': [
                    {
                        'VolumeSpecification': {
                            'VolumeType': 'st1',
                            'SizeInGB': ebs_disk
                        },
                        'VolumesPerInstance': 1
                    },
                ],
                'EbsOptimized': True}
        else:
            ebs_configuration = {}

        # Get environment from global variable
        environment = self.ENVIRONMENT
        config_environment = environment

        if config_environment == 'prd':
            config_environment = ""

        # Default applications to load in cluster
        if applications is None:
            applications = ["Spark", "Hadoop", "Livy"]
        if release_label is None:
            release_label = 'emr-6.5.0'

        # Add Spark for comercial DAGs
        # TODO: To be removed after dependent dag update, backward compatibility purpose
        if owner == 'comercial':
            applications.append('Spark')

        # Format application list for run_job_flow cluster creation call
        app_list = [dict(zip(['Name'], [app])) for app in dict.fromkeys(applications)]

        #check if cluster already exists
        
        if pd.DataFrame(self.EMR.list_clusters(ClusterStates=['RUNNING','WAITING'])['Clusters']).query(f"Name=='{self.CLUSTER_NAME}'").size == 0:
            cluster_response = self.EMR.run_job_flow(
                Name=cluster_name,
                LogUri=f's3n://ddpawslogs{config_environment}/elasticmapreduce/{cluster_name}/',
                ReleaseLabel=release_label,
                Instances={
                    'InstanceGroups': [
                        {
                            'Name': 'Maestro - 1',
                            'Market': 'ON_DEMAND',
                            'InstanceRole': 'MASTER',
                            'InstanceType': instance_type_name,
                            'InstanceCount': 1,
                            'EbsConfiguration': ebs_configuration,
                        },
                        {
                            'Name': 'Principal - 2',
                            'Market': 'ON_DEMAND',
                            'InstanceRole': 'CORE',
                            'InstanceType': instance_type_name,
                            'InstanceCount': number_core_instances,
                            'EbsConfiguration': ebs_configuration,
                        },
                    ],
                    'Ec2KeyName': 'CoE_DAAI',
                    'KeepJobFlowAliveWhenNoSteps': True,
                    'TerminationProtected': False,
                    'Ec2SubnetId': 'subnet-0a3379481cc9731f7',
                    'EmrManagedMasterSecurityGroup': 'sg-0610ab82c321a0eee',
                    'EmrManagedSlaveSecurityGroup': 'sg-0f122e1a6aba8175e',
                    'ServiceAccessSecurityGroup': 'sg-04ce3473ed4abe379',
                },
                BootstrapActions=[
                    {
                        'Name': 'Parquet files',
                        'ScriptBootstrapAction': {
                            'Path':
                                f's3://ddpawsconfig{config_environment}'
                                f'/emr/bootstrap/cluster/cluster-bootstrap-copy-parquet-jar.sh'
                        }
                    },
                    {
                        'Name': 'Copy ojdbc',
                        'ScriptBootstrapAction': {
                            'Path':
                                f's3://ddpawsconfig{config_environment}'
                                f'/emr/bootstrap/cluster/cluster-bootstrap-copy-jdbc.sh'
                        }
                    },
                    {
                        'Name': 'Copy Key',
                        'ScriptBootstrapAction': {
                            'Path':
                                f's3://ddpawsconfig{config_environment}'
                                f'/emr/bootstrap/cluster/cluster-bootstrap-copy-key.sh'
                        }
                    },
                    {
                        'Name': 'System init customizations',
                        'ScriptBootstrapAction': {
                            'Path':
                                f's3://ddpawsconfig{config_environment}'
                                f'/emr/bootstrap/cluster/cluster-bootstrap-system-init.sh'
                        }
                    },
                    {
                        'Name': 'DDNS configuration into ulysses domain',
                        'ScriptBootstrapAction': {
                            'Path':
                                f's3://ddpawsconfig{config_environment}'
                                f'/emr/bootstrap/cluster/cluster-bootstrap-ddns.sh'
                        }
                    }
                ],
                Applications=app_list,
                Configurations=[
                    {
                        'Classification': 'emrfs-site',
                        'Properties': {
                            'python': 'python3.8',
                            'fs.s3.consistent.retryPeriodSeconds': '10',
                            'fs.s3.consistent': 'false',
                            'fs.s3.consistent.retryCount': '5',
                            'fs.s3.consistent.metadata.tableName': 'EmrFSMetadata'
                        }
                    },
                    {
                        'Classification': 'spark-env',
                        'Properties': {
                            'spark.pyspark.python': 'python3',
                            'spark.pyspark.virtualenv.enabled': 'true',
                            'spark.pyspark.virtualenv.type':'native',
                            'spark.pyspark.virtualenv.bin.path':'/usr/bin/virtualenv'
                        }
                    },
                    {
                        'Classification': 'spark-defaults',
                        'Properties': {
                            'spark.driver.memory': '32G'
                        }
                    },
                    {
                        'Classification': 'spark-hive-site',
                        'Properties': {
                            'hive.metastore.client.factory.class':
                                'com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory'
                        }
                    },
                    {
                        "Classification": "livy-conf",
                        "Properties": {
                            "livy.server.session.timeout-check": "true",
                            "livy.server.session.timeout": "2h",
                            "livy.server.yarn.app-lookup-timeout": "120s",
                            "livy.spark.deploy-mode":"cluster"
                        }
                    },
                    {
                        "Classification": "yarn-env",
                        "Properties": {
                            "yarn.nm.liveness-monitor.expiry-interval-ms": "1800000"
                        }
                    }
                ],
                VisibleToAllUsers=True,
                ServiceRole='EMR_DefaultRole',
                JobFlowRole='EMR_EC2_DefaultRole',
                Tags=[
                    {
                        'Key': 'project',
                        'Value': project
                    },
                    {
                        'Key': 'environment',
                        'Value': environment
                    },
                    {
                        'Key': 'application',
                        'Value': 'emr'
                    },
                    {
                        'Key': 'applicationType',
                        'Value': 'ds_workspace'
                    },
                    {
                        'Key': 'owner',
                        'Value': owner
                    }
                ],
                AutoScalingRole='EMR_AutoScaling_DefaultRole',
                ScaleDownBehavior='TERMINATE_AT_TASK_COMPLETION',
                AutoTerminationPolicy= {"IdleTimeout":3600},
                ManagedScalingPolicy = { "ComputeLimits": {
                                            "MaximumOnDemandCapacityUnits":2,
                                            "UnitType":"Instances",
                                            "MaximumCapacityUnits":10,
                                            "MinimumCapacityUnits":2,
                                            "MaximumCoreCapacityUnits":2 }
                                            },
                EbsRootVolumeSize=100,
                StepConcurrencyLevel=256
            )
            self.cluster_id = cluster_response['JobFlowId']
        else:
            self.cluster_id = pd.DataFrame(self.EMR.list_clusters(ClusterStates=['RUNNING','WAITING','STARTING','BOOTSTRAPPING'])['Clusters']).query(f"Name=='{self.CLUSTER_NAME}'")['Id'].iloc[0]
            self.EMR.get_waiter('cluster_running').wait(ClusterId=self.cluster_id)
            print('Already created host: '+self.CLUSTER_NAME.replace('-','').replace('_','')+'.emr.ulysses.galpenergia.corp')


    def wait_for_cluster_creation(self):
        """
        This functions waits until the given AWS EMR Cluster ID to be ready to perform jobs.
        """
        self.EMR.get_waiter('cluster_running').wait(ClusterId=self.cluster_id)
        print('host: '+self.CLUSTER_NAME.replace('-','').replace('_','')+'.emr.ulysses.galpenergia.corp')
        return self.CLUSTER_NAME.replace('-','').replace('_','')+'.emr.ulysses.galpenergia.corp'

    def terminate_cluster(self):
        """
        This function terminates a AWS EMR cluster associated with the given Cluster ID.
        """
        try:
            self.EMR.terminate_job_flows(JobFlowIds=[self.cluster_id])

        except botocore.exceptions.ClientError as e:
            if e.response['Error']['Code'] == 'ValidationException':
                print(e)
            else:
                raise e
