import os
import socket
import findspark
import subprocess
from kubernetes import config
from pyspark import SparkConf
from pyspark.sql import SparkSession

# Define constants for the cluster settings and the AWS region
REGION = "eu-west-1"

SPARK_CLUSTER_NAME = os.getenv('SPARK_CLUSTER_NAME')
SPARK_MASTER = os.getenv('SPARK_MASTER')
SPARK_IMAGE = os.getenv('SPARK_IMAGE')
SPARK_VERSION = os.getenv('SPARK_VERSION')


class SparkManager:
    """
    Class to manage the PySpark session and provide utilities for querying 
    and interacting with data.
    """

    def __init__(self, instances="3", memory="1g", cores="1"):
        """
        Initializes the SparkClient object and configure the SparkSession.
        Parameters:
        - instances (str): The number of instances to use for Spark.
        - memory (str): The amount of memory to allocate for Spark.
        - cores (str): The number of cores to allocate for Spark.
        """
        
        self._load_spark_environment()
        self.spark = self._get_spark_session(instances, memory, cores)

    def _get_all_jars_from_directory(self, directory="/opt/jars"):
        """
        Returns a comma-separated string of all the jar files in the specified directory.
        Parameters:
        - directory (str): The directory path where the jar files are located. Default is "/opt/jars".
        Returns:
        - str: A comma-separated string of all the jar files in the specified directory.
        """
        
        jar_files = [os.path.join(directory, jar) for jar in os.listdir(directory) if jar.endswith('.jar')]
        return ','.join(jar_files)
    import os

    def _check_credentials(self):
        """
        Check if the credentials environment variables are set and if so, create the AWS credentials file.
        """
        
        # Check if environment variables are set
        aws_access_key = os.environ.get('AWS_ACCESS_KEY_ID')
        aws_secret_key = os.environ.get('AWS_SECRET_ACCESS_KEY')

        if not aws_access_key or not aws_secret_key:
            print()
            raise ValueError(f"Environment variables AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY are not set!")

        # Path to the credentials file. By default, it's ~/.aws/credentials
        credentials_path = os.path.expanduser("~/.aws/credentials")

        # Check if the ~/.aws directory exists, if not, create it
        os.makedirs(os.path.dirname(credentials_path), exist_ok=True)

        # Write the credentials to the file
        with open(credentials_path, 'w') as file:
            file.write("[default]\n")
            file.write(f"aws_access_key_id = {aws_access_key}\n")
            file.write(f"aws_secret_access_key = {aws_secret_key}\n")


    def _check_jar_files(self, directory="/opt/jars"):
        """
        Check if the necessary JAR files are present in the specified directory.
        If any are not present, raise an exception.
        Parameters:
            directory (str, optional): The directory path where the JAR files are located. Defaults to "/opt/jars".
        Raises:
            FileNotFoundError: If any of the JAR files are missing.
        """

        missing_jars = []
        for jar in os.listdir(directory):
            jar_path = os.path.join(directory, jar)
            if jar.endswith('.jar') and not os.path.isfile(jar_path):
                missing_jars.append(jar_path)

        if missing_jars:
            raise FileNotFoundError(f"Missing JAR files: {', '.join(missing_jars)}")

    def _load_spark_environment(self):
        """
        Initialize the spark environment and check for the necessary kubeconfig.
        If an error is found, raise an exception.
        """

        # self._check_credentials()
        findspark.init()

        if not (SPARK_CLUSTER_NAME and SPARK_MASTER and SPARK_IMAGE and SPARK_VERSION):
            raise EnvironmentError('At least one spark variable is empty.')

        config.load_kube_config()

    def _get_spark_session(self, instances="3", memory="1g", cores="1"):
        """
        Configure the Spark session and return the SparkSession object.
        Parameters:
            instances (str): The number of executor instances to be created. Default is "3".
            memory (str): The amount of memory to be allocated for each executor. Default is "1g".
            cores (str): The number of cores to be allocated for each executor. Default is "1".
        Returns:
            SparkSession: The created SparkSession object.
        """

        # settings = CLUSTER_SETTINGS.get(os.environ.get('ENVIRONMENT'))
        self._check_jar_files()
        current_context = config.list_kube_config_contexts()[1]
        hostname = socket.gethostname()
        ip_address = socket.gethostbyname(hostname)
        conf = (SparkConf().setMaster(f"k8s://{SPARK_MASTER}")
                # .set("spark.kubernetes.container.image", settings['image'])
                .set("spark.kubernetes.container.image", f"{SPARK_IMAGE}:{SPARK_VERSION}")
                .set("spark.kubernetes.namespace", "cortex-spark-jobs")
                .set("spark.pyspark.python", "/usr/bin/python")
                .set("spark.sql.execution.arrow.pyspark.enabled", "true")
                .set("spark.jars", self._get_all_jars_from_directory())
                .set("spark.ssl.noCertVerification", "true")
                .set("spark.kubernetes.driverEnv.SPARK_CONF_DIR", "/opt/spark/conf")
                .set("spark.kubernetes.context", current_context['context']['cluster'])
                .set("spark.kubernetes.driver.podTemplateFile", "/opt/spark-templates/template_driver_jobs-spark.yaml")
                .set("spark.kubernetes.executor.podTemplateFile", "/opt/spark-templates/template_executor_jobs-spark.yaml")
                # .set("spark.kubernetes.driver.tolerations",
                #      '{"key": "ulysses/role", "operator": "Equal", "value": "jobs", "effect": "NoSchedule"}')
                # .set("spark.kubernetes.executor.tolerations",
                #      '{"key": "ulysses/role", "operator": "Equal", "value": "jobs", "effect": "NoSchedule"}')
                .set("spark.kubernetes.node.selector.ulysses/node_name", "cortex-jobs")
                .set("spark.driver.host", ip_address)
                .set("spark.submit.deployMode", "client")
                .set("spark.driver.bindAddress", "0.0.0.0")
                .set("spark.executor.instances", instances)
                .set("spark.executor.memory", memory)
                .set("spark.executor.cores", cores)
                .set("spark.kubernetes.container.image.pullPolicy", "Always")
                .set("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
                .set("spark.hadoop.fs.s3a.endpoint", "s3.amazonaws.com")
                .set("spark.hadoop.fs.s3a.access.key", os.getenv('AWS_ACCESS_KEY_ID'))
                .set("spark.hadoop.fs.s3a.secret.key", os.getenv('AWS_SECRET_ACCESS_KEY'))
                .set("spark.app.name", os.getenv('JUPYTERHUB_CLIENT_ID')))
        
        return SparkSession.builder.config(conf=conf).getOrCreate()

    def query_ulysses(self, query, user, password, url="datahub.ulysses.galpenergia.corp", port=32010, use_encryption=True, disable_certificate_validation=True):
        """
        Executes a query on Ulysses Datahub and returns the result as a DataFrame.
        Parameters:
            query (str): The SQL query to be executed.
            user (str): The username for authentication.
            password (str): The password for authentication.
            url (str, optional): The URL of the Ulysses datahub. Defaults to "datahub.ulysses.galpenergia.corp".
            port (int, optional): The port number for the Ulysses datahub. Defaults to 32010.
            use_encryption (bool, optional): Whether to use encryption for the connection. Defaults to True.
            disable_certificate_validation (bool, optional): Whether to disable certificate validation. Defaults to True.
        Returns:
            DataFrame: The result of the query as a DataFrame.
        Raises:
            Exception: If the query execution fails.
        """

        jdbc_url = f"jdbc:arrow-flight-sql://{url}:{port}"
        connection_properties = {"user": user, "password": password, "driver": "org.apache.arrow.driver.jdbc.ArrowFlightJdbcDriver", "useEncryption": str(use_encryption).lower(),"disableCertificateVerification": str(disable_certificate_validation).lower()}
        try:
            return self.spark.read.format("jdbc").option("url", jdbc_url).option("query", query).options(**connection_properties).load()
        except Exception as e:
            raise Exception("Failed to execute query on Ulysses: {e}")

    def load_data_from_workspaces(self, file_path, file_format):
        """
        Load data from an S3 bucket and return a DataFrame with the loaded data.
        Parameters:
            file_path (str): The path of the file to load.
            file_format (str): The format of the file.
        Returns:
            DataFrame: The loaded data.
        Raises:
            Exception: If there is an error loading the data.
        """

        try:
            return self.spark.read.format(file_format).load(file_path)
        except Exception as e:
            raise Exception(f"Failed to load data from S3: {e}")

    def write_data_to_workspace(self, df, file_path, file_format, mode="overwrite"):
        """
        Write a DataFrame to an S3 bucket in the specified file path in the specified file format.
        Parameters:
            df (DataFrame): The DataFrame to be written.
            file_path (str): The path where the DataFrame will be written.
            file_format (str): The format in which the DataFrame will be written.
            mode (str, optional): The write mode. Defaults to "overwrite".
        Raises:
            Exception: If there is an error while writing the data to the workspace.
        """

        try:
            df.write.format(file_format).mode(mode).save(file_path)
        except Exception as e:
            raise Exception(f"Failed to write data to workspace: {e}")
