import requests
import json
import xml.etree.ElementTree as ET
import os
import shutil

import gitlab
import git


class PipelineManager:
    """
    The PipelineManager class manage Jenkins pipelines and Gitlab

    Attributes:
        jenkins_url (str): Jenkins URL for pipelines to be created
        jenkins_user (str): Programatic user to access Jenkins from code
        jenkins_token (str): Token defined for authentication
        gitlab_url (str): Base URL for Gitlab repositories
        gitlab_token (str): Token to access Gitlab resources
        project (str): Project ID at Galp -> PXXXXX
        github_repo (str): Repository name at Github
        template_job_name (str): Jenkins job used as template
        template_repo_name (str): Gitlab repo name used as template
        model_name (str): Model of the name, it will be used to name all new elements
        ca_cert_path (str): Path to Ulysses certificate
        project_id_template (str): Id of the template repository in Gitlab
        sbx_env (str): DEaaS account created and associated to this project. Ex: SBX_03
    """

    def __init__(self, project, github_repo, sbx_env):
        """
        Constructor for Client class.

        Parameters:
            project (str): Project ID at Galp -> PXXXXX
            github_repo (str): Repository name at Github
            sbx_env (str): DEaaS account created and associated to this project. Ex: SBX_03
        """
        self.jenkins_url = 'http://prd-aws-ddp-jenkins-master.ulysses.galpenergia.corp/'
        self.jenkins_user = "sagithub"
        self.jenkins_token = '1186fdaf13c7dd8822bf126836624caa53'
        self.gitlab_url = 'http://gitlab.ulysses.galpenergia.corp'
        self.gitlab_token = 'hxkvVM9oP6ybP4TCbJwa'
        self.project = project
        self.github_repo = github_repo
        self.template_job_name = 'galp-coedaai-mlops-template-model'
        self.template_repo_name = 'galp-coedaai-mlops-template-project'
        self.model_name = self.github_repo.replace("data_science-", "").replace("_model", "")\
            .replace("-", " ").replace("_", " ").title()
        self.ca_cert_path = 'hub/docker/certificates/ca_bundle_ulysses.crt'
        self.project_id_template = 581
        self.sbx_env = sbx_env.upper()
        self.sbx_env_number = sbx_env[-2:]

    @staticmethod
    def set_parent(element, parent=None):
        """
        Helper function to recursively set parent for each element
        """
        element.set('parent', parent)
        for child in element:
            PipelineManager.set_parent(child, element)

    @staticmethod
    def remove_parent_attributes(element):
        """
        Remove parent attributes before converting back to string
        """
        element.attrib.pop('parent', None)
        for child in element:
            PipelineManager.remove_parent_attributes(child)

    def create_automation_pipeline(self):
        """
        Creates an automation pipeline for the specified model.
        This method generates a new Jenkins job based on a template job and updates the configuration file with the 
        specified values. The new job is created with the modified configuration file.
        Returns:
            None
        """

        pipeline_display_name = f'Galp CoE DAAI {self.model_name}'
        print(f"Model name is {self.model_name} and it will be displayed as {pipeline_display_name}.")

        # Template job and new job names
        new_job_name = f'galp-coedaai-{self.project.lower()}-{self.model_name.replace(" ", "-").lower()}-model'
        print(f'New pipeline name is {new_job_name}.\n'
              f'This name must be configured in Github as repository variable with:\n'
              f'Name: ULYSSES_PIPELINE_REPOSITORY_NAME\n'
              f'Value: {new_job_name}')

        pipeline_description = f'Get files from a Github repository and build a docker image. ' \
                               f'This pipeline is for {self.model_name}.'

        # API URLs to get config file from template job.
        create_job_url = f'{self.jenkins_url}/createItem?name={new_job_name}'
        config_xml_url = f'{self.jenkins_url}/job/{self.template_job_name}/config.xml'

        response = requests.get(config_xml_url, auth=(self.jenkins_user, self.jenkins_token))
        if response.status_code != 200:
            print(f'Failed to get config.xml from template job: {response.status_code}')
            exit(1)

        config_xml = response.text

        # Update config file with new values
        new_values = {
            'displayName': pipeline_display_name,
            'pipeline_description': pipeline_description,
            'repository': self.github_repo,
            'repositoryUrl': 'https://github.com/galpenergia/' + self.github_repo,
            'includes': 'deployment_staging_branch deployment_main_branch'
        }

        # Load and parse XML template
        root = ET.fromstring(config_xml)

        # Set parent attributes
        PipelineManager.set_parent(root)

        # Find and replace specific elements
        for elem in root.iter():
            if elem.tag == 'description':
                parent_tag = elem.get('parent').tag if elem.get('parent') is not None else None
                if 'WorkflowMultiBranchProject' in parent_tag:
                    elem.text = new_values['pipeline_description']
            elif elem.tag in new_values:
                elem.text = new_values[elem.tag]

        PipelineManager.remove_parent_attributes(root)

        # Save the modified XML to a string
        modified_xml = ET.tostring(root, encoding='unicode')

        # Create the new job with the modified config.xml
        headers = {'Content-Type': 'application/xml'}
        response = requests.post(create_job_url, data=modified_xml, headers=headers,
                                 auth=(self.jenkins_user, self.jenkins_token))
        if response.status_code == 200:
            print(f'\nSuccessfully created job {new_job_name} from template {self.template_job_name}')
        else:
            print(f'Failed to create job: {response.status_code}')
            print(response.text)

    def create_ulysses_repository(self):
        """
        Creates a new repository by cloning a template repository, creating a new repository in the Cortex group,
        and pushing the contents to the new repository. It also copies variables from the template repository and pastes
        them in the new repository.
        Returns:
            None
        """

        # Names of the template repository and new repository
        template_repo_url = self.gitlab_url + "/cortex/" + self.template_repo_name + '.git'
        new_repo_name = f'galp-coedaai-{self.project.lower()}-{self.model_name.lower().replace(" ", "-")}-model'
        print(f'New repository {new_repo_name} will be created from template {template_repo_url}')

        gl = gitlab.Gitlab(self.gitlab_url, private_token=self.gitlab_token,
                           api_version=4, ssl_verify=self.ca_cert_path)
        gl.auth()

        # Clone the template repository locally
        clone_url = template_repo_url.replace('http://', f'https://oauth2:{self.gitlab_token}@')

        # Clean temp path and download template repo
        local_path = '/tmp/template_repo'
        if os.path.exists(local_path):
            shutil.rmtree(local_path)
        repo = git.Repo.clone_from(clone_url, local_path, config='http.sslVerify=false')
        print(f'New repository "{new_repo_name}" created from template repository "{self.template_repo_name}"')

        # Identify Cortex group to create a new repository inside this group
        group_id = gl.groups.list(search='cortex')[0].id
        new_project = gl.projects.create({'name': new_repo_name, 'namespace_id': group_id})

        # Add the new repository as a remote and push the contents
        new_repo_url = new_project.http_url_to_repo.replace('http://', f'https://oauth2:{self.gitlab_token}@')
        origin = repo.create_remote('new_origin', new_repo_url)
        origin.push()

        # Create the master branch and push it to the new repository
        repo.git.push('new_origin', 'master')

        print(f'New repository created: {new_project.web_url}')
        print(f'Dev branch created and pushed to {new_project.web_url}')

        # Copy variables from template repo and paste them in new repo
        variables = gl.projects.get(self.project_id_template).variables.list()
        dpm_host_key = 'DPM_HOST_SBX'
        db_password_key = 'DB_PASSWORD_SBX'
        mlflow_host_sbx_key = 'MLFLOW_HOST_SBX'

        for var in variables:
            if var.key == 'DPM_HOST_' + self.sbx_env:
                new_project.variables.create(
                    {'key': dpm_host_key, 'value': var.value, 'protected': var.protected, 'masked': var.masked})
                print(f"Copied variable {var.key} as {dpm_host_key}")
            elif var.key == 'DB_PASSWORD_' + self.sbx_env:
                new_project.variables.create(
                    {'key': db_password_key, 'value': var.value, 'protected': var.protected, 'masked': var.masked})
                print(f"Copied variable {var.key} as {db_password_key}")
            elif var.key == "MLFLOW_HOST_SBX":
                new_project.variables.create(
                    {'key': mlflow_host_sbx_key, 'value': var.value.replace("XX", self.sbx_env_number), 'protected': var.protected, 'masked': var.masked})
                print(f"Copied variable {var.key} as {mlflow_host_sbx_key}")
            else:
                new_project.variables.create(
                    {'key': var.key, 'value': var.value, 'protected': var.protected, 'masked': var.masked})
                print(f"Copied variable {var.key}.")
