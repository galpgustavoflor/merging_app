from .pyarrowClient import connect_to_dremio_flight_server_endpoint, parse_arguments

class Client:
   
    def __init__(self, username, password):
        self.username = username
        self.password = password
        self.host = "datahub.ulysses.galpenergia.corp"
        self.port = 32010
        print("This module was deprecated please use the: from ulysses import datahub_connector")

    def set_host(host, port):
        if ((host!="") or ~(host is None)):
            self.host = host
        if ((port!="") or ~(port is None)):
            self.port = port
            
        print(f'[info] switched to {self.host} on port {self.port}')


    def query(self, query):
        return connect_to_dremio_flight_server_endpoint(self.host, self.port, self.username, self.password, query,
                                                True, False, True, False, False, False)

    def list_tables(self):
        query = 'select * from INFORMATION_SCHEMA."TABLES"'
        return connect_to_dremio_flight_server_endpoint(self.host, self.port, self.username, self.password, query,
                                                True, False, True, False, False, False)

    def list_columns(self, table):
        query = f"select * from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME='{table}'"
        return connect_to_dremio_flight_server_endpoint(self.host, self.port, self.username, self.password, query,
                                                True, False, True, False, False, False)



if __name__ == "__main__":
    # Parse the command line arguments.
    args = parse_arguments()
    # Connect to Dremio Arrow Flight server endpoint.
    ret = Client(args.username, args.password)

    